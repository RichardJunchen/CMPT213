package UI;

import GameLogic.GameMatrix;
import GameLogic.PackageGame;
import GameLogic.StatisticsTable;

import java.util.ArrayList;
import java.util.Scanner;

public class TokimonFinder {
    /*
    @ par three argument pass to main
    @ uses To check which mode we will handle
     */
    public static String[] checkNumber(String[] args) {
        String[] userInput = {"10", "5"};
        String[] cheatMode = {"10", "5", "--cheat"};
        boolean check = false;
        int sum = 0;
        for (String arg : args) {
            if (arg.contains("cheat")) {
                check = true;
                break;
            }
        }
        /*
        Ex: --numToki=6 ---cheat
         */
        if (args.length == 2 && check) {
            System.out.println(" Miss a input data, changing the default mode! ");
            return cheatMode;
        }
        /*
        Ex: --numToki=6/ ---cheat
         */
        if (args.length == 1) {
            System.out.println(" Miss a input data, changing the default mode! ");
            if (check)
                return cheatMode;
            else
                return userInput;
        }
        /*
        Ex: --numToki=6 --numFoki=7 ---cheat / --numToki=6 --numFoki=7/ --numToki=623 --numFoki=7
         */
        for (String s : args) {
            if (!s.contains("cheat") && Integer.parseInt(s) <= 5) {
                if (check)
                    return cheatMode;
                else
                    return userInput;
            } else if (!s.contains("cheat") && Integer.parseInt(s) >= 5) {
                sum += Integer.parseInt(s);
            }
        }
        if (sum > 100 && check) {
            System.out.println(" Inputs are invalid we will use default number ");
            return cheatMode;
        } else if (sum > 100)
            return userInput;
        else
            return args;
    }
    /*
   @ par String of each instruct
   @ uses To extract the number contain in the each instruct
    */
    public static String findNum(String instruct) {
        String temp2 = "";
        for (int i = 0; i < instruct.length(); i++) {
            if (instruct.charAt(i) >= 48 && instruct.charAt(i) <= 57) {
                temp2 += instruct.charAt(i);
            }
        }
        return temp2;
    }
    /*
   @ par argument pass to main
   @ uses separate number and cheat and rest of string
    */
    public static String[] argumentCheck(String[] args) {
        for (int i = 0; i < args.length; i++) {
            for (int j = 0; j < args[i].length(); j++) {
                if (args[i].charAt(j) == '=')
                    args[i] = findNum(args[i]);
            }
        }
        return checkNumber(args);
    }
    /*
   @ par current game and list of spells
   @ uses To print current state of game and spells
    */
    public static void printCurrentGame(GameMatrix game, ArrayList<String> list) {
        System.out.println("-------------Game Grid :--------------");
        System.out.println("------------------------");
        System.out.println("| Found Tokimons: " + game.getTable().getGetToki() + "|");
        System.out.println("| Rest Tokimons: " + game.getTable().getRestToki() + "|");
        System.out.println("| Rest Spells: " + game.getTable().getRestSpells() + "|");
        System.out.println("------------------------");
        System.out.println(game);
        System.out.println("------------------------------------------------------------------");
        System.out.println(" If you want to use a spell, enter \"spells\" and choose number");
        System.out.println(" Spells ：");
        if (!list.isEmpty()) {
            for (int i = 0; i < list.size(); i++) System.out.println(i + 1 + "." + list.get(i));
        }
        else{
            System.out.println(" Nothing here !");
        }
        System.out.println("------------------------------------------------------------------");
    }
    /*
   @ par current game and list of spells
   @ uses To check if it is cheat mode
    */
    public static void check_cheat(PackageGame game, ArrayList<String> list ){
        if (game.isCheat())
            printCurrentGame(game.getCheat_game(),list);
        else {
            printCurrentGame(game.getNormal_game(), list);
        }
    }
    public static void main(String[] args) {
        final int numRow = 12;
        final int numCol = 12;
        String[] userInput = {"10", "5"};
        boolean cheat = false;
        ArrayList<String> list = new ArrayList<>();
        list.add("  Jump the player to another grid location");
        list.add("  Randomly reveal the location of one of the Tokimons");
        list.add("  Randomly kill off one of the Fokimons");
        if (args.length == 0)
            System.out.println(" we will use our default set number");
        else
            userInput = TokimonFinder.argumentCheck(args);
        for (String s : userInput) {
            if (s.contains("cheat")) {
                cheat = true;
                break;
            }
        }
        StatisticsTable details = new StatisticsTable(0, Integer.parseInt(userInput[0]), list.size(),0);
        System.out.println(" Please enter a initial position (Composed by letter(A~J) and digit (1~10)) : ");
        Scanner in = new Scanner(System.in);
        String ini_position = in.nextLine();
        char[] coordinate = GameMatrix.check_position(ini_position);
        PackageGame game;
        GameMatrix game_one = GameMatrix.generateGame(numRow, numCol, Integer.parseInt(userInput[0]),
                Integer.parseInt(userInput[1]), true, details,coordinate);
        GameMatrix game_two = GameMatrix.generateGame(numRow, numCol, Integer.parseInt(userInput[0]),
                Integer.parseInt(userInput[1]), false, details,coordinate);
        GameMatrix.initializePosition(game_two,coordinate,details,game_one);

        if (cheat)
            game = new PackageGame(game_two,game_one,true);
        else
            game = new PackageGame(game_two,game_one,false);

        check_cheat(game,list);

        while (game.getCheat_game().getTable().getRestToki()> 0){
            GameMatrix.eachStep(game.getNormal_game(),game.getCheat_game(),details,list);
            check_cheat(game,list);
        }
        if (game.getCheat_game().getTable().getRestToki() == 0)
        {
            System.out.println(" ------> YOU WIN THIS GAME <------");
            System.out.println(game_one);
            System.out.println("------------------------------------------------------------------");
            System.out.println("------------------------------------------------------------------");
            System.out.println(" -------  Statistic Table  ------- ");
            System.out.println("----------------------------------");
            System.out.println("| Found Tokimons: " + game.getCheat_game().getTable().getGetToki() + "|");
            System.out.println("| Rest Tokimons: " + game.getCheat_game().getTable().getRestToki() + "|");
            System.out.println("| Rest Spells: " + game.getCheat_game().getTable().getRestSpells() + "|");
            System.out.println("| Total step: " + game.getCheat_game().getTable().getStep_number() + "|");
            System.out.println("----------------------------------");
            System.out.println(" Game designer : Junchen Li");
            System.out.println(" Designer ID : 301385486");
            System.out.println("----------------------------------");
            System.out.println(" Thank you for playing game,Have a great day!!");
        }
    }
}
