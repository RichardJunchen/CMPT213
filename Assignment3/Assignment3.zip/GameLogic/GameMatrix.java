package GameLogic;

import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

public class GameMatrix {
     private final String [][] game;
     private final int numRow;
     private final int numCol;
     private final StatisticsTable table;

    public GameMatrix (int row, int col, int toki, int foki, StatisticsTable detail, boolean check){
        numRow = row;
        numCol = col;
        game = new String[row][col];
        table = detail;
    }

    public StatisticsTable getTable() {
        return table;
    }
    /*
       @ par current game
       @ uses end game when meet Fokimon
        */
     public static void end_game(GameMatrix cheat_mode){
         System.out.println(" Unfortunately, you meet a Fokimon!!! GAME END ");
         System.out.println(cheat_mode);
         System.out.println("| Found Tokimons: " + cheat_mode.getTable().getGetToki() + "|");
         System.out.println("| Rest Tokimons: " + cheat_mode.getTable().getRestToki() + "|");
         System.out.println("| Rest Spells: " + cheat_mode.getTable().getRestSpells() + "|");
         System.out.println("| Total step: " + cheat_mode.getTable().getStep_number() + "|");

         System.out.println("----------------------------------");
         System.out.println(" Game designer : Junchen Li");
         System.out.println(" Designer ID : 301385486");
         System.out.println("----------------------------------");
         System.out.println(" Thank you for playing game,Have a great day!!");
         System.exit(0);
     }
    /*
  @ par current game and nume of Tokimons
  @ uses To put Tokimons randomly
   */
    public static void generateTokimons(GameMatrix normal, int numToki) {
        for (int i = 0; i < numToki; i++) {
            Random random = new Random();
            // [m,n] = random.nextInt()*(n - m + 1) + m
            int num1 = random.nextInt(10) + 1;
            int num2 = random.nextInt(10) + 1;
            if (normal.game[num1][num2].equals(" "))
                normal.game[num1][num2] = "$";
             else
                continue;
            }
    }
    /*
    @ par current game and nume of Fokimons
    @ uses To put Fokimons Randomly
    */
    public static void generateFokimons(GameMatrix normal, int numFoki){
        for (int i =0; i< numFoki; i++)
        {
            Random random = new Random();
            // [m,n] = random.nextInt()*(n - m + 1) + m
            int num1 = random.nextInt(10)+1;
            int num2 = random.nextInt(10)+1;
            if (normal.game[num1][num2].equals(" "))
                normal.game[num1][num2] = "X";
            else
                continue;
        }
    }
    /*
   @ par empty game
   @ uses To generate normal game mode
   */
    public static void normalMode (GameMatrix cheat){
         for (int i =1; i < cheat.numRow-1; i++){
             for (int j = 1; j< cheat.numCol-1; j++)
                 cheat.game[i][j] = "~";
         }
    }
    /*
   @ par number of two corrd points and two modes
   @ uses To check if we touch the boundary of game
   */
    public static void check_wall (int first, int second,GameMatrix normal,GameMatrix cheat){
         if(first == 1 && second == 10) {
             normal.game[1][9] = cheat.game[1][9];
             normal.game[2][10] = cheat.game[2][10];
         }
         else if (second == 10) {
             normal.game[first -1 ][second] = cheat.game[first - 1][second];
             normal.game[first][second - 1] = cheat.game[first][second - 1];
         }
         if (first == 10){
             normal.game[first - 1][second] = cheat.game[first - 1][second];
             normal.game[first][second + 1] = cheat.game[first][second + 1];
         }
         else{
             normal.game[first][second + 1] = cheat.game[first][second + 1];
             normal.game[first + 1][second] = cheat.game[first + 1][second];
         }

    }
    /*
   @ par number of two corrd points and two modes
   @ uses To check if we meet a Tokimons or Fokimons
   */
    public static void checkIfMeet (int first, int second, StatisticsTable detail,
                                    GameMatrix normal_mode,GameMatrix cheat_mode){
         if (cheat_mode.game[first][second].equals("$")){
             System.out.println(" ---> Congratulation!!! You find a Tokimon !!! <---");
             detail.setRestToki(detail.getRestToki() - 1);
             detail.setGetToki(detail.getGetToki() + 1);
             cheat_mode.game[first][second] = "$@";
             normal_mode.game[first][second] = "$@";

             check_wall(first,second,normal_mode,cheat_mode);
         }
         else if (cheat_mode.game[first][second].equals("X")){
             cheat_mode.game[first][second] = "X@";
             normal_mode.game[first][second] = "X@";
             end_game(cheat_mode);
         }

         else {
             cheat_mode.game[first][second] = "@";
             normal_mode.game[first][second] = "@";
         }

    }
    /*
   @ par number of two corrd points and two modes and table of data
   @ uses To put our first input as a "@"
   */
    public static void initializePosition (GameMatrix mode, char[] coordinate, StatisticsTable detail,
                                           GameMatrix cheat_mode){
         int first = 0;
         int second = 0;
         if (coordinate[0]>= 65 && coordinate[0] <= 74)
             first = coordinate[0] - 64;
         else if (coordinate[0]>= 97 && coordinate[0] <= 106)
             first = coordinate[0] - 96;
         if (coordinate[1]>= 49 && coordinate[1] <= 57)
            second = coordinate[1] - 48;
         if (coordinate.length == 3)
             second = 10;
         checkIfMeet(first, second, detail, mode,cheat_mode);

    }
    /*
   @ par string of instruct
   @ uses To check if instruct is usable
   */
    public static boolean check_usable(String instruct){
        return instruct.equals("w")||instruct.equals("W")||instruct.equals("A")||instruct.equals("a")||
                instruct.equals("S")||instruct.equals("s")||instruct.equals("d")||instruct.equals("D")||
                instruct.equals("Spells")||instruct.equals("spells")||instruct.equals("SPELLS");
    }
    /*
   @ par string of instruct
   @ uses to check if input is vaild
   */
    public static char[] check_position(String position) {
        char[] temp = position.toCharArray();

        Scanner in = new Scanner(System.in);
        if (temp.length != 2 && temp.length != 3) {
            System.out.println(" Sorry you input size is invalid , Please try again : ");
            System.out.println(" Please enter a initial position (Composed by letter(A~J) and digit (1~10)) : ");
            String again = in.nextLine();
            check_position(again);
        }
        boolean check = (temp[0] >= 65 && temp[0] <= 74)||(temp[0] >= 97 && temp[0] <= 106);
        if (temp.length == 3) {
            if (check && temp[1] == '1' && temp[2] == '0')
                return temp;
            else {
                System.out.println(" Sorry you input can not recognize , Please try again : ");
                System.out.println(" Please enter a initial position (Composed by letter(A~J) and digit (1~10)) : ");
                String again = in.nextLine();
                check_position(again);
            }
        }
        if (temp.length == 2) {
            if (check && (temp[1] >= 49 && temp[1] <= 57)) {
                return temp;
            } else {
                System.out.println(" Sorry you input can not recognize , Please try again : ");
                System.out.println(" Please enter a initial position (Composed by letter(A~J) and digit (1~10)) : ");
                String again = in.nextLine();
                check_position(again);
            }
        }
        return temp;
    }
    /*
   @ par number of spells, two game mode, table of details, list of instruct, two points
   @ uses handle when user choose to use spells
   */
    public  static  void spell_work (int spell_num, GameMatrix normal_game, GameMatrix cheat_game,
                                     StatisticsTable detail, ArrayList<String> list, int first, int second){
        String instruct = list.get(spell_num);
        int numOfSpell = detail.getRestSpells();
        int numOfRestToki = detail.getRestToki();
        int numOfGetToki = detail.getGetToki();
        boolean finished = true;
        if (instruct.contains("Jump")){
            System.out.println(" Please enter a position you want to transfer (Composed by letter(A~J) and digit (1~10)) : ");
            Scanner in = new Scanner(System.in);
            String ini_position = in.nextLine();
            char[] coordinate = check_position(ini_position);
            normal_game.game[first][second] = " ";
            cheat_game.game[first][second] = " ";
            initializePosition(normal_game,coordinate,detail,cheat_game);
            list.remove(spell_num);
            detail.setRestSpells(numOfSpell-1);
        }
        else if (instruct.contains("Tokimons")){
            for (int i =0; i< normal_game.numRow; i++){
                for (int j =0; j< normal_game.numCol; j++){
                    if (finished){
                        if (cheat_game.game[i][j].equals("$")) {
                            System.out.println(" We use infrared scanning to help you to find one Tokimon");
                            cheat_game.game[i][j] = " ";
                            normal_game.game[i][j] = " ";
                            finished = false;
                        }
                    }
                }
            }
            list.remove(spell_num);
            detail.setRestSpells(numOfSpell-1);
            detail.setRestToki(numOfRestToki - 1);
            detail.setGetToki(numOfGetToki + 1);
        }
        else{
            for (int i =0; i< normal_game.numRow; i++){
                for (int j =0; j< normal_game.numCol; j++){
                    if (finished){
                        if (cheat_game.game[i][j].equals("X")) {
                            System.out.println(" We use UAV to kill a Fokimon. Keep safe !!!");
                            cheat_game.game[i][j] = " ";
                            normal_game.game[i][j] = " ";
                            finished = false;
                        }
                    }
                }
            }
            list.remove(spell_num);
            detail.setRestSpells(numOfSpell-1);
        }

    }
    /*
   @ par two modes of game, detaild table, instruct and list of instruct
   @ uses To check if we can move W/A/S/D/Spells
   */
    public static void moveStep (GameMatrix normal_game, GameMatrix cheat_game,
                                 StatisticsTable detail, String instruct, ArrayList<String> list){
        int first = 0;
        int second = 0;
        int spell_num;
        for (int i =0; i< cheat_game.numRow;i++){
            for (int j =0; j < cheat_game.numCol;j++){
                if (cheat_game.game[i][j].contains("@")) {
                    first = i;
                    second = j;
                }
            }
        }
        if (instruct.equals("W") || instruct.equals("w"))
        {
            if (first ==1)
                System.out.println(" You can not move, you are on the most top part !");
            else{
                int step = cheat_game.table.getStep_number();
                cheat_game.table.setStep_number(step+1);

                cheat_game.game[first][second] = " ";
                normal_game.game[first][second] = " ";
                first -=1;
                checkIfMeet(first,second,detail,normal_game,cheat_game);
            }
        }
        if (instruct.equals("A") || instruct.equals("a"))
        {
            if (second ==1)
                System.out.println(" You can not move, you are on the most left part !");
            else{
                int step = cheat_game.table.getStep_number();
                cheat_game.table.setStep_number(step+1);

                cheat_game.game[first][second] = " ";
                normal_game.game[first][second] = " ";
                second -=1;
                checkIfMeet(first,second,detail,normal_game,cheat_game);
            }
        }
        if (instruct.equals("S") || instruct.equals("s"))
        {
            if (first ==10)
                System.out.println(" You can not move, you are on the most bottom part !");
            else {
                int step = cheat_game.table.getStep_number();
                cheat_game.table.setStep_number(step+1);

                cheat_game.game[first][second] = " ";
                normal_game.game[first][second] = " ";
                first +=1;
                checkIfMeet(first,second,detail,normal_game,cheat_game);
            }
        }
        if (instruct.equals("D") || instruct.equals("d"))
        {
            if (second ==10)
                System.out.println(" You can not move, you are on the most right part !");
            else{
                int step = cheat_game.table.getStep_number();
                cheat_game.table.setStep_number(step+1);

                cheat_game.game[first][second] = " ";
                normal_game.game[first][second] = " ";
                second +=1;
                checkIfMeet(first,second,detail,normal_game,cheat_game);
            }
        }
        if (instruct.equals("Spells") || instruct.equals("SPELLS")|| instruct.equals("spells")){
            if(detail.getRestSpells() == 0){
                System.out.println("You don't have any Spells for using");
            }
            else{
                do {
                    System.out.println(" Which spells you want to use ? Enter a number ");
                    Scanner in = new Scanner(System.in);
                    spell_num = in.nextInt();
                }while (spell_num < 1 && spell_num > detail.getRestSpells());
                spell_work(spell_num-1,normal_game,cheat_game,detail,list,first,second);
            }
        }
    }
    /*
   @ par number of two mode of game and detail table and list of instruct
   @ uses To check each step is vaild
   */
    public static void eachStep (GameMatrix normal_game, GameMatrix cheat_game,
                                 StatisticsTable detail, ArrayList<String> list){
        Scanner in = new Scanner(System.in);
        String instruct = in.nextLine();
        boolean check = check_usable(instruct);
        while (!check){
            System.out.println(" Can not recognize your input, please enter it again ");
            instruct = in.nextLine();
            check = check_usable(instruct);
        }
        moveStep(normal_game,cheat_game,detail,instruct,list);
    }
    /*
   @ par number of two corrd points and bool cheat yes or not
   @ uses To generate the rough game
   */
    public static GameMatrix generateGame (int row, int col, int numToki, int numFoki,
                                           boolean cheat, StatisticsTable detail, char[] coordinate){
         GameMatrix normal_mode = new GameMatrix(row,col,numToki,numFoki,detail,cheat);
         GameMatrix cheat_mode = new GameMatrix(row,col,numToki,numFoki,detail,cheat);
         normal_mode.game[0][0] = " ";
         cheat_mode.game[0][0] = " ";
         char colTitle= 'A';
         for (int i =1; i<row-1; i++){
             normal_mode.game[0][i] = String.valueOf(i);
             normal_mode.game[i][0] = String.valueOf(colTitle);
             cheat_mode.game[0][i] = String.valueOf(i);
             cheat_mode.game[i][0] = String.valueOf(colTitle);
             colTitle +=1;
         }
        for (int w =0; w<row; w++){
            normal_mode.game[col-1][w]="-";
            cheat_mode.game[col-1][w]="-";
            normal_mode.game[w][row-1]="|";
            cheat_mode.game[w][row-1]="|";
        }
         if (cheat){
             for (int j =1; j<row-1; j++){
                 for (int k = 1; k < col-1; k++)
                     cheat_mode.game[j][k] = " ";
             }
             generateTokimons(cheat_mode,numToki);
             generateFokimons(cheat_mode,numFoki);
             initializePosition(cheat_mode,coordinate,detail,cheat_mode);
             return cheat_mode;
         }
         else {
             normalMode(normal_mode);
         }
             return normal_mode;
     }
     @Override
     public String toString(){
         String ret = "";
         for (int i =0; i < numRow; i++){
             for (int j =0; j < numCol; j++){
                 ret+=game[i][j];
                 if (!(j==numCol - 1))
                     ret += "  ";
             }
             ret +="\n";
         }
         return ret;
     }
}
