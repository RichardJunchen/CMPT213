package GameLogic;

public class PackageGame {
    private GameMatrix normal_game;
    private GameMatrix cheat_game;
    private boolean cheat;

    public PackageGame(GameMatrix normal_game, GameMatrix cheat_game, boolean cheat) {
        this.normal_game = normal_game;
        this.cheat_game = cheat_game;
        this.cheat = cheat;
    }

    public GameMatrix getNormal_game() {
        return normal_game;
    }

    public void setNormal_game(GameMatrix normal_game) {
        this.normal_game = normal_game;
    }

    public GameMatrix getCheat_game() {
        return cheat_game;
    }

    public void setCheat_game(GameMatrix cheat_game) {
        this.cheat_game = cheat_game;
    }

    public boolean isCheat() {
        return cheat;
    }

    public void setCheat(boolean cheat) {
        this.cheat = cheat;
    }

}