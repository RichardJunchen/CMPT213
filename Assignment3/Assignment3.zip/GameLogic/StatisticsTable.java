package GameLogic;

public class StatisticsTable {
    private int getToki;
    private int restToki;
    private int restSpells;
    private int step_number;

    public int getStep_number() {
        return step_number;
    }

    public void setStep_number(int step_number) {
        this.step_number = step_number;
    }

    public StatisticsTable(int getToki, int restToki, int restSpells,int step_number) {
        this.getToki = getToki;
        this.restToki = restToki;
        this.restSpells = restSpells;
        this.step_number = step_number;
    }
    public int getGetToki() {
        return getToki;
    }

    public void setGetToki(int getToki) {
        this.getToki = getToki;
    }

    public int getRestToki() {
        return restToki;
    }

    public void setRestToki(int restToki) {
        this.restToki = restToki;
    }

    public int getRestSpells() {
        return restSpells;
    }

    public void setRestSpells(int restSpells) {
        this.restSpells = restSpells;
    }


}
