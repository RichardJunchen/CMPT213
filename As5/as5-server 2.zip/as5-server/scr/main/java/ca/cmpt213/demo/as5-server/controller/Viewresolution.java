package main.java.com.hw.controller;

import main.java.com.hw.pojo.Tokimon;
import org.apache.commons.codec.binary.StringUtils;import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.annotation.DeleteMapping;
import javax.annotation.PostConstruct;

import org.springframework.http.HttpStatus;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

@Controller
public class Viewresolution {

    @RequestMapping("/hw/select")
    @ResponseBody
    public List<String> init(String id,String name){
//
        String queryListStr = FileUtil.readFile("tokimon.json");
        List<Tokimon> L =JSON.parseArray(queryListStr,Tokimon.class);
        if(id != null && !"".equals(id.trim()))
        {
            for(int i =0 ;i<L.size();i++)
            {
                if(id.equals(L.get(i).getId()))
                {

                }
                else
                {
                    L.remove(i);
                    i--;
                }
            }
        }


        if(name != null && !"".equals(name.trim()))
        {
            for(int i =0 ;i<L.size();i++)
            {
                if(name.equals(L.get(i).getName()))
                {

                }
                else
                {
                    L.remove(i);
                    i--;
                }
            }
        }
        List<String> re=new ArrayList<>();
        for(int i =0 ;i<L.size();i++)
        {
            re.add(L.get(i).toString());
        }
        return re;

    }


    @RequestMapping("DELETE /api/tokimon/{id}")
    @ResponseBody
    public List<String> delete(String ids){

        String queryListStr = FileUtil.readFile("tokimon.json");
            List<Tokimon> L =JSON.parseArray(queryListStr,Tokimon.class);
        if(ids != null && !"".equals(ids.trim()))
        {
            String[] S = ids.split(",");
            for(int i =0 ;i<S.length;i++)
            {
                for(int j =0 ;j<L.size();j++)
                {
                    if(S[i].equals(L.get(j).getId()))
                    {

                        L.remove(j);
                        j--;
                    }

                }
            }
        }

        FileUtil.writerFileNoAdd("tokimon.json",JSON.toJSONString(L));

        List<String> re=new ArrayList<>();
        for(int i =0 ;i<L.size();i++)
        {
            re.add(L.get(i).toString());
        }
        return re;

    }


    @RequestMapping("POST /api/tokimon/change/{id}")
    @ResponseBody
    public List<String> modify(Tokimon tokimon){

        String queryListStr = FileUtil.readFile("tokimon.json");
        List<Tokimon> L =JSON.parseArray(queryListStr,Tokimon.class);



                for(int j =0 ;j<L.size();j++)
                {
                    if(tokimon.getId().equals(L.get(j).getId()))
                    {
                        L.set(j,tokimon);

                    }

                }



        FileUtil.writerFileNoAdd("tokimon.json",JSON.toJSONString(L));

        List<String> re=new ArrayList<>();
        for(int i =0 ;i<L.size();i++)
        {
            re.add(L.get(i).toString());
        }
        return re;

    }

    @RequestMapping("POST /api/tokimon/add")
    @ResponseBody
    public List<String> add(Tokimon tokimon){

        String queryListStr = FileUtil.readFile("tokimon.json");
        List<Tokimon> L =JSON.parseArray(queryListStr,Tokimon.class);


        L.add(tokimon);



        FileUtil.writerFileNoAdd("tokimon.json",JSON.toJSONString(L));

        List<String> re=new ArrayList<>();
        for(int i =0 ;i<L.size();i++)
        {
            re.add(L.get(i).toString());
        }
        return re;

    }















}
